# Code Citations

## License: LGPL-3.0
[https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx](https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx)

```
svg
```


## License: 0BSD
https://github.com/a8t/blog/blob/d2318fec7da28f7a7f41a08b3250274f5184c8f5/src/components/navbar.tsx

```
svg
```


## License: LGPL-3.0
[https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx](https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx)

```
svg className="h
```


## License: 0BSD
https://github.com/a8t/blog/blob/d2318fec7da28f7a7f41a08b3250274f5184c8f5/src/components/navbar.tsx

```
svg className="h
```


## License: LGPL-3.0
[https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx](https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx)

```
svg className="h-6 w-
```


## License: 0BSD
https://github.com/a8t/blog/blob/d2318fec7da28f7a7f41a08b3250274f5184c8f5/src/components/navbar.tsx

```
svg className="h-6 w-
```


## License: LGPL-3.0
[https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx](https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx)

```
svg className="h-6 w-6" fill="none
```


## License: 0BSD
https://github.com/a8t/blog/blob/d2318fec7da28f7a7f41a08b3250274f5184c8f5/src/components/navbar.tsx

```
svg className="h-6 w-6" fill="none
```


## License: LGPL-3.0
[https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx](https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx)

```
svg className="h-6 w-6" fill="none" view
```


## License: 0BSD
https://github.com/a8t/blog/blob/d2318fec7da28f7a7f41a08b3250274f5184c8f5/src/components/navbar.tsx

```
svg className="h-6 w-6" fill="none" view
```


## License: LGPL-3.0
[https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx](https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx)

```
svg className="h-6 w-6" fill="none" viewBox="0 0
```


## License: 0BSD
https://github.com/a8t/blog/blob/d2318fec7da28f7a7f41a08b3250274f5184c8f5/src/components/navbar.tsx

```
svg className="h-6 w-6" fill="none" viewBox="0 0
```


## License: LGPL-3.0
[https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx](https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx)

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24"
```


## License: 0BSD
https://github.com/a8t/blog/blob/d2318fec7da28f7a7f41a08b3250274f5184c8f5/src/components/navbar.tsx

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24"
```


## License: LGPL-3.0
[https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx](https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx)

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
```


## License: 0BSD
https://github.com/a8t/blog/blob/d2318fec7da28f7a7f41a08b3250274f5184c8f5/src/components/navbar.tsx

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
```


## License: LGPL-3.0
[https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx](https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx)

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke
```


## License: 0BSD
https://github.com/a8t/blog/blob/d2318fec7da28f7a7f41a08b3250274f5184c8f5/src/components/navbar.tsx

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke
```


## License: LGPL-3.0
[https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx](https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx)

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="roun
```


## License: 0BSD
https://github.com/a8t/blog/blob/d2318fec7da28f7a7f41a08b3250274f5184c8f5/src/components/navbar.tsx

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="roun
```


## License: LGPL-3.0
[https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx](https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx)

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin
```


## License: 0BSD
https://github.com/a8t/blog/blob/d2318fec7da28f7a7f41a08b3250274f5184c8f5/src/components/navbar.tsx

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin
```


## License: LGPL-3.0
[https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx](https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx)

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth
```


## License: 0BSD
https://github.com/a8t/blog/blob/d2318fec7da28f7a7f41a08b3250274f5184c8f5/src/components/navbar.tsx

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth
```


## License: LGPL-3.0
[https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx](https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx)

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="
```


## License: 0BSD
https://github.com/a8t/blog/blob/d2318fec7da28f7a7f41a08b3250274f5184c8f5/src/components/navbar.tsx

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="
```


## License: LGPL-3.0
[https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx](https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx)

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L
```


## License: 0BSD
https://github.com/a8t/blog/blob/d2318fec7da28f7a7f41a08b3250274f5184c8f5/src/components/navbar.tsx

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L
```


## License: LGPL-3.0
[https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx](https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx)

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6
```


## License: 0BSD
https://github.com/a8t/blog/blob/d2318fec7da28f7a7f41a08b3250274f5184c8f5/src/components/navbar.tsx

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6
```


## License: LGPL-3.0
[https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx](https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx)

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 
```


## License: 0BSD
https://github.com/a8t/blog/blob/d2318fec7da28f7a7f41a08b3250274f5184c8f5/src/components/navbar.tsx

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 
```


## License: LGPL-3.0
[https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx](https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx)

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
  
```


## License: 0BSD
https://github.com/a8t/blog/blob/d2318fec7da28f7a7f41a08b3250274f5184c8f5/src/components/navbar.tsx

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
  
```


## License: LGPL-3.0
[https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx](https://github.com/bigbluebutton/bigbluebutton/blob/7087f5276d2d7dc5d8faf6cb427303ae16abf2cb/bbb-learning-dashboard/src/components/UserDetails/component.jsx)

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
  </svg>
```


## License: 0BSD
https://github.com/a8t/blog/blob/d2318fec7da28f7a7f41a08b3250274f5184c8f5/src/components/navbar.tsx

```
svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
  </svg>
```

